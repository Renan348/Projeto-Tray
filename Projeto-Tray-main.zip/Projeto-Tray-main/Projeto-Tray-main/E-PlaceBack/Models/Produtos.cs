﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Eplace.Models
{
    public class Produtos
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "O modelo é obrigatório.")]
        [StringLength(100, ErrorMessage = "O modelo pode ter no máximo 100 caracteres.")]
        public string Modelo { get; set; }

        [Required(ErrorMessage = "A marca é obrigatória.")]
        [StringLength(50, ErrorMessage = "A marca pode ter no máximo 50 caracteres.")]
        public string Marca { get; set; }

        private float _preco;

        [Range(0, float.MaxValue, ErrorMessage = "O preço deve ser um valor positivo.")]
        public float Preco
        {
            get => _preco;
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(value), "O preço não pode ser negativo.");
                _preco = value;
            }
        }

        private int _quantidadeEmEstoque;

        [Range(0, int.MaxValue, ErrorMessage = "A quantidade em estoque deve ser um valor positivo.")]
        public int QuantidadeEmEstoque
        {
            get => _quantidadeEmEstoque;
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(value), "A quantidade em estoque não pode ser negativa.");
                _quantidadeEmEstoque = value;
            }
        }

        public bool MercadoLivre { get; set; }
        public bool AliExpress { get; set; }
        public bool Shopee { get; set; }

        [DataType(DataType.DateTime)]
        [Required]
        public DateTime DataCadastro { get; set; }

        // Construtor principal
        public Produtos(string modelo, string marca, float preco, int quantidadeEmEstoque, bool mercadoLivre, bool aliExpress, bool shopee)
        {
            this.Modelo = modelo;
            this.Marca = marca;
            this.Preco = preco;
            this.QuantidadeEmEstoque = quantidadeEmEstoque;
            this.MercadoLivre = mercadoLivre;
            this.AliExpress = aliExpress;
            this.Shopee = shopee;
            this.DataCadastro = DateTime.Now; // Define a data de cadastro como a data atual
        }

        // Construtor padrão necessário para o Entity Framework
        private Produtos() { }
    }
}
