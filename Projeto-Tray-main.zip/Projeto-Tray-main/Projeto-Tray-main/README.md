# Eplace 
Uma solução simplificada para gerenciar multiplus ecommerces em um hub unificado a fim de auxiliar comércios com a integração em multiplas plataformas

## passo-a-passo
1) Instalar o Visual Studio 
2) Assegurar que possui a versão 8.0 ou superior do .Net
3) Baixar o projeto
4) Abrir o Eplace.csproj no Visual Studio
5) No terminal do Visual Studio Executar: dotnet ef database update
6) Rodar o projeto no visual studio
7) Abrir a pasta E-Place no cmd e Executar: npm install
8) No mesmo terminal executar: npm run dev

### Integrantes
- Matheus Gabriel e Silva
  - 1967134 
- Silvio de Moraes neto
  - 1969365
- Renan Solano
  - 1968758
- Vinicius Medeiros
  - 
- Henrique Medeiros  
  - 1976730 
